package net.javaguides.springmvc.service;

import net.javaguides.springmvc.model.Customer;

public interface CustomerService {
	public void saveCustomer(Customer theCustomer);
}
