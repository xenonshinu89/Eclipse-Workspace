package net.javaguides.springmvc.dao;

import net.javaguides.springmvc.model.Customer;

public interface CustomerDAO {
	void saveCustomer(Customer theCustomer);
}
